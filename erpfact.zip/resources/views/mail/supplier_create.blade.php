<h1>Congratulation {{$name}}!</h1>
<h3>Hope that our deal will be prosperous</h3>
<p>Thank you</p>